SITIO WEB: Auditorías Alimentarias - Edeinmy

Este sitio incluye:
- index.html (Inicio)
- servicios.html
- plantillas.html
- contacto.html
- Archivos descargables: PDF, Excel, ZIP
- Estilos en CSS
- Lista para subir a tu hosting

Pasos para subir:
1. Descomprime el ZIP
2. Sube todo a tu hosting o servidor
3. Accede con tu dominio: https://tudominio.com/index.html
