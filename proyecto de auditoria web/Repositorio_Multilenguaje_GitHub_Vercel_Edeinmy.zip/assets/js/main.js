
const textos = {
  es: {
    titulo: "Auditorías Alimentarias",
    navInicio: "Inicio",
    navServicios: "Servicios",
    navPlantillas: "Plantillas",
    navContacto: "Contacto",
    bienvenida: "Bienvenida",
    parrafoPrincipal: "Todo lo que necesitas para auditar, evaluar y cumplir normativas alimentarias."
  },
  en: {
    titulo: "Food Safety Audits",
    navInicio: "Home",
    navServicios: "Services",
    navPlantillas: "Templates",
    navContacto: "Contact",
    bienvenida: "Welcome",
    parrafoPrincipal: "Everything you need to audit, assess and comply with food safety standards."
  },
  fr: {
    titulo: "Audits de Sécurité Alimentaire",
    navInicio: "Accueil",
    navServicios: "Services",
    navPlantillas: "Modèles",
    navContacto: "Contact",
    bienvenida: "Bienvenue",
    parrafoPrincipal: "Tout ce dont vous avez besoin pour auditer, évaluer et respecter les normes alimentaires."
  }
};

function cambiarIdioma(idioma) {
  for (const clave in textos[idioma]) {
    document.getElementById(clave).innerText = textos[idioma][clave];
  }
}
